import sys, io, os, json
sys.path.insert(0,'work')
import numpy as np, cv2, resvg_py
from PIL import Image
import pipe, logo
phi=(1+5**.5)/2
ROOT='The_Awesome_Logo_Final'
def spiral_pts(x,y,w,h,n=9):
    pts=[]
    for k in range(n):
        st=k%4
        if st==0: s=h; c=(x+s,y+s); a0,a1=np.pi,1.5*np.pi; x+=s; w-=s
        elif st==1: s=w; c=(x,y+s); a0,a1=1.5*np.pi,2*np.pi; y+=s; h-=s
        elif st==2: s=h; c=(x+w-s,y); a0,a1=0,0.5*np.pi; w-=s
        else: s=w; c=(x+w,y+h-s); a0,a1=0.5*np.pi,np.pi; h-=s
        a=np.linspace(a0,a1,60); pts.append(np.c_[c[0]+s*np.cos(a),c[1]+s*np.sin(a)])
    return pts
def squares(x,y,w,h,n=9):
    sq=[]
    for k in range(n):
        st=k%4
        if st==0: s=h; sq.append((x,y,s)); x+=s; w-=s
        elif st==1: s=w; sq.append((x,y,s)); y+=s; h-=s
        elif st==2: s=h; sq.append((x+w-s,y,s)); w-=s
        else: s=w; sq.append((x,y+h-s,s)); h-=s
    return sq
rep=[]
for nm,suf,bgc in (('dark','Dark',(0,0,0)),('light','Light',(255,255,255))):
    v,G,faces,fits,wm=pipe.run(nm)
    defs,sb=logo.sym_defs_and_body(faces,fits)
    logo.WM={'head':{'paths':wm['head']['paths']},'tag':{'paths':wm['tag']['paths']}}
    col='#ffffff' if nm=='dark' else '#000000'
    svg=logo.wrap((0,0,pipe.FW,pipe.FH),defs,'<g>'+sb+'</g>'+logo.wm_body(col),bg='#%02x%02x%02x'%bgc)
    img=np.array(Image.open(io.BytesIO(bytes(resvg_py.svg_to_bytes(svg_string=svg)))).convert('RGB'))
    sym=np.vstack([faces[k].poly() for k in faces]); hb=np.array(wm['head']['bbox']); tb=np.array(wm['tag']['bbox'])
    hx0=hb[:,0,0].min(); hx1=hb[:,1,0].max(); Wr=hx1-hx0; y0=sym[:,1].min(); Hr=Wr/phi
    Hreal=hb[:,1,1].max()-y0
    # golden rectangle: headline width x (width/phi), anchored at symbol top; spiral drawn inside
    gold=(255,190,0) if nm=='dark' else (200,120,0)
    ov=img.copy()
    for (sx,sy,s) in squares(hx0,y0,Wr,Hr): cv2.rectangle(ov,(int(sx),int(sy)),(int(sx+s),int(sy+s)),gold,1,cv2.LINE_AA)
    for P in spiral_pts(hx0,y0,Wr,Hr): cv2.polylines(ov,[P.round().astype(np.int32)],False,(255,60,60),3,cv2.LINE_AA)
    # actual block (symbol top -> headline bottom)
    cv2.rectangle(ov,(int(hx0),int(y0)),(int(hx1),int(y0+Hreal)),(60,160,255),2,cv2.LINE_AA)
    out=cv2.addWeighted(ov,0.85,img,0.15,0)
    X0,Y0,X1,Y1=int(hx0-80),int(y0-60),int(hx1+80),int(tb[:,1,1].max()+60)
    Image.fromarray(out[Y0:Y1,X0:X1]).save(os.path.join(ROOT,'06_Comparison','Golden_Ratio_Overlay_%s.png'%suf))
    hw=hb[:,1,0].max()-hb[:,0,0].min(); capH=np.median(hb[:,1,1]-hb[:,0,1]); capT=np.median(tb[:,1,1]-tb[:,0,1])
    gap1=hb[:,0,1].min()-sym[:,1].max(); gap2=tb[:,0,1].min()-hb[:,1,1].max()
    rep.append((suf,dict(W=Wr,Hreal=Hreal,Hgold=Hr,ratio=Wr/Hreal,cap=capH/capT,gap=gap1/gap2,hw_sw=hw/(sym[:,0].max()-sym[:,0].min()),symWH=(sym[:,0].max()-sym[:,0].min())/(sym[:,1].max()-sym[:,1].min()))))
def pct(x,t): return '%+.1f%%'%(100*(x/t-1))
d=dict(rep)['Dark']; l=dict(rep)['Light']
md=f'''# 황금비(피보나치 황금나선) 분석 — Golden_Ratio_Analysis

기준값: φ = 1.618, φ² = 2.618. 두 로고의 **실제 측정값**이 φ에 얼마나 가까운지 확인한 결과다. 겹침 이미지: `06_Comparison/Golden_Ratio_Overlay_Dark.png`, `..._Light.png`
(금색 칸 = 피보나치 사각형 분할, 빨간 선 = 황금나선, 파란 사각형 = 실제 로고 블록).

## 결과 요약
- **레이아웃(글자·간격·블록 비율)은 이미 황금비에 맞게 되어 있다.** 원본 디자인이 의도적으로 황금비를 쓴 것으로 보인다. 그래서 이 부분은 고치지 않았다.
- **심볼 자체의 도형(가로세로 비, 아치 곡선 반지름 등)은 황금비가 아니다.** 원본에서 이렇게 측정되었고, 황금비에 맞추면 원본 모양이 바뀌므로 억지로 맞추지 않았다.

| 항목 | 다크 | 라이트 | 황금비 목표 | 판정 |
|---|---|---|---|---|
| (제목 폭) ÷ (심볼 꼭대기~제목 아래 높이) | {d['ratio']:.3f} ({pct(d['ratio'],phi)}) | {l['ratio']:.3f} ({pct(l['ratio'],phi)}) | 1.618 | 근접 — **블록이 황금사각형** |
| 심볼 아래~제목 위 간격 ÷ 제목 아래~태그라인 위 간격 | {d['gap']:.3f} ({pct(d['gap'],phi)}) | {l['gap']:.3f} ({pct(l['gap'],phi)}) | 1.618 | 일치(±0.2%) |
| 제목 대문자 높이 ÷ 태그라인 대문자 높이 | {d['cap']:.3f} ({pct(d['cap'],phi**2)}) | {l['cap']:.3f} ({pct(l['cap'],phi**2)}) | 2.618 | 다크 일치, **라이트는 16% 큼** |
| 제목 폭 ÷ 심볼 폭 | {d['hw_sw']:.3f} ({pct(d['hw_sw'],phi)}) | {l['hw_sw']:.3f} ({pct(l['hw_sw'],phi)}) | 1.618 | 근접 |
| 심볼 가로 ÷ 세로 | {d['symWH']:.3f} | {l['symWH']:.3f} | — | 황금비 아님(원본 형태) |

## 황금나선과 아치 곡선
아치 아래쪽 가장자리에 황금나선(회전당 φ배로 감기는 로그나선, b=ln φ÷(π/2))과 원호를 각각 맞춰 보았다.
- 아래쪽 가장자리: 원 오차 평균 2.7px(다크)/3.6px(라이트), 황금나선 2.8px/3.6px로 **차이가 없다.** 나선이 더 낫다는 근거가 없어 원호를 유지했다.
- 위쪽 가장자리: 원은 8.4~9.9px, 황금나선은 6.6~8.2px로 나선이 약간 더 가깝지만 둘 다 현재 쓰는 맞춤(오차 2~3px)보다 크다. 바꾸면 원본에서 더 벗어나므로 바꾸지 않았다.

## 수정하지 않은 이유와 남은 선택지
- 라이트의 태그라인 크기(대문자 높이비 3.05)만 황금비(2.618)에서 눈에 띄게 벗어나 있다. 이것은 **라이트 원본 이미지가 실제로 그렇다.** 태그라인을 키워 맞추면 라이트 원본에서 벗어나고, 글자 간격(자간) 비율도 달라진다. 필요하면 선택할 수 있다.
- 제목 블록 높이는 다크가 이상값보다 2.3% 낮고 라이트가 1.1% 높다. 원본 측정 오차 범위로 보고 고치지 않았다.
'''
open(os.path.join(ROOT,'07_Documentation','Golden_Ratio_Analysis.md'),'w',encoding='utf-8').write(md)
print(json.dumps(dict(rep),indent=1,default=float))
