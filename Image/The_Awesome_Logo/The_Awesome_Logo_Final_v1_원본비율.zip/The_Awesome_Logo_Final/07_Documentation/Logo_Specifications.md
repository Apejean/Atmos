# 로고 규격 (Logo_Specifications)

| 항목 | 값 |
|---|---|
| 심볼 | 은색 금속 리본 "A" — 5개 면(`leg_right`, `leg_left`, `arch_front`, `arch_right_low`, `arch_right_band`) |
| 심볼 가로세로 비 | 다크 1.331 : 1, 라이트 1.263 : 1 (원본 이미지 2장이 서로 다름) |
| 전체 로고 viewBox | 다크 `49.7 69.1 2025.7 1464.6`, 라이트 `20.0 68.0 2071.3 1539.3` |
| 워드마크 | THE AWESOME / TECHNOLOGY × ARTISTRY — 윤곽선 패스(글꼴 의존 없음) |
| 글자색 | 다크 배경용 #FFFFFF, 라이트 배경용 #000000 |
| 금속 면 색 | 면별 그라디언트(회색~백색~차콜). SVG의 `linearGradient g_*`(기본), `h_*`(오버레이) 참조 |
| 배경 | 모든 로고 파일 투명(앱 아이콘 제외) |

## 파일
- `02_SVG` : Symbol_Only(다크 버전), Symbol_Only_Light(추가), Wordmark_Tagline(검정), Wordmark_Tagline_White(추가), Full_Logo_Light, Full_Logo_Dark
- `03_PNG` : 투명 배경. 심볼 1024×1024 캔버스(다크 버전 심볼), 전체 로고 가로 3000px
- `04_App_Icons` : Windows.ico(정사각 꽉 채움), macOS.icns(표준 여백·그림자), 각 1024 PNG, 라이트/다크 둥근 PNG
- `05_Illustrator` : PDF(라이트/다크, 순수 벡터·소프트마스크), EPS(축소 충실도), Illustrator_Compatible.svg
- `06_Comparison` : 원본 대조(다크 기준은 접미사 없음, 라이트는 `_Light`)
- `07_Documentation/source_scripts` : 제작에 쓴 Python 스크립트(재현용)

## 앱 아이콘 (04_App_Icons)
- `Windows.ico` / `AppIcon_Windows_Square_1024.png` : **모서리까지 꽉 채운 검정 정사각형** 바탕에 다크 심볼(폭 66%). 16·24·32·48·64·128·256px 포함(ICO 형식 한계로 256px까지).
- `macOS.icns` / `AppIcon_macOS_1024.png` : macOS 표준 형태. 1024 캔버스에 824px 둥근 사각형(여백 100px, 모서리 반경 185)과 부드러운 그림자, 다크 심볼(타일 폭의 62%). 16–1024px 포함.
- `AppIcon_Dark_1024.png`, `AppIcon_Light_1024.png` : 이전 둥근 사각형 PNG(참고용).
치수(심볼 비율, 둥근 정도, 그림자)는 Apple의 일반적인 아이콘 템플릿을 기준으로 눈대중으로 맞춘 값이며 원본에서 측정한 값이 아니다.

## SVG 편집
각 금속 면은 `<g id="면이름">` 아래 두 path(기본 그라디언트, 오버레이)로 되어 있고 같은 `d`를 쓰므로 모양을 바꿀 때 함께 수정한다. 글자는 글자별 path(`THE_AWESOME_n`, `TECHNOLOGY_ARTISTRY_n`).
