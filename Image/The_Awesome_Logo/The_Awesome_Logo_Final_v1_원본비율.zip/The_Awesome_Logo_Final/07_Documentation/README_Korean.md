# The Awesome 로고 패키지

기존 로고를 **새로 디자인하지 않고**, 제공받은 2000px 원본 이미지(다크/라이트)에서 추적·재현한 벡터 세트입니다. 원본과 100% 동일하다고 주장하지 않습니다. 측정된 차이와 의도적으로 정리한 부분은 `07_Documentation/Vectorization_Differences.md`, 원본 대조는 `06_Comparison`에 있습니다.

## 폴더
```
The_Awesome_Logo_Final/
 01_Original_Reference/  원본 이미지, 분석 보고서, 기준 도면
 02_SVG/                 Symbol_Only, Wordmark_Tagline, Full_Logo_Light, Full_Logo_Dark (+추가 변형)
 03_PNG/                 투명 PNG
 04_App_Icons/           Windows.ico(정사각), macOS.icns(표준 여백), 1024 PNG들
 05_Illustrator/         Full_Logo_Light/Dark.pdf, Full_Logo.eps, Illustrator_Compatible.svg
 06_Comparison/          원본/벡터/겹침/차이/외곽선 비교
 07_Documentation/       문서와 제작 스크립트
```

## 사용 요령
- 밝은 배경 → `Full_Logo_Light`, 어두운 배경 → `Full_Logo_Dark`. 이 둘은 원본 이미지가 서로 다른 도형이라 **각각 따로 추적**한 것입니다.
- SVG는 순수 벡터(PNG 삽입 없음). 면별 `<g id>`로 편집할 수 있습니다.
- Illustrator: `Full_Logo_*.pdf`를 여는 것을 권장합니다(그라디언트와 투명 마스크 유지). `.ai`로 저장하려면 열어서 "다른 이름으로 저장".
- `Full_Logo.eps`는 음영이 단순한 축소 버전입니다(투명도 미지원, 렌더링 미검증).

## 알려둘 점
- 원본이 약간 흐려서 가장자리 위치 오차는 약 1.51~2.01px(작업 좌표, 심볼 폭 1070 기준)입니다. 음영은 근사입니다.
- 가장자리는 의도적으로 직선/호로 정리했고, 일부 글자(A·W·M, 태그라인의 N·L·I·Y·×·C·G·R)는 측정값으로 다시 구성했습니다. 자세한 내용은 차이점 문서를 보세요.
- 제작 도구: Python 3.15, OpenCV, NumPy, SciPy, Shapely, Pillow, resvg, PyMuPDF.
